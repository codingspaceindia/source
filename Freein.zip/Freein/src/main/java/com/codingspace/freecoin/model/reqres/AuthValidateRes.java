package com.codingspace.freecoin.model.reqres;

public class AuthValidateRes {
    String token;
}
